#include "HeapManager.h"

#include "DefaultHeap.h"
#include "../GlobalDefines.h"

HeapManager* HeapManager::instance = nullptr;
DefaultHeap* HeapManager::defaultHeap = new DefaultHeap("DEFAULT");

HeapManager* HeapManager::Instance()
{
    if (instance == nullptr)
    {
        instance = new HeapManager();
    }
    return instance;
}

void* HeapManager::operator new(size_t size)
{
    VERBOSE_OUTPUT(std::cout << "{HeapManager} New Called" << std::endl;)
    return ManagedObject::operator new(size, defaultHeap);
}
void HeapManager::operator delete(void* pMem)
{
    VERBOSE_OUTPUT(std::cout << "{HeapManager} Delete Called" << std::endl;)
    ::operator delete(pMem);
}
void* HeapManager::operator new[](size_t size)
{
    VERBOSE_OUTPUT(std::cout << "{HeapManager} New[] Called" << std::endl;)
    return ManagedObject::operator new[](size, defaultHeap);
}
void HeapManager::operator delete[](void* pMem)
{
    VERBOSE_OUTPUT(std::cout << "{HeapManager} Delete[] Called" << std::endl;)
    ::operator delete[](pMem);
}

Heap* HeapManager::GetDefaultHeap()
{
    return dynamic_cast<Heap*>(defaultHeap);
}

Heap* HeapManager::GetHeap(const char* heapName)
{
    if (heaps.find(heapName) == heaps.end())
    {
        heaps[heapName] = new Heap(heapName);
    }
    return heaps[heapName];
}

HeapManager::HeapManager()
{
    VERBOSE_OUTPUT(std::cout << "{HeapManager} Constructor" << std::endl;)
    heaps = std::unordered_map<const char*, Heap*>();
}
HeapManager::~HeapManager()
{
    VERBOSE_OUTPUT(std::cout << "{HeapManager} Deconstructor" << std::endl;)
    for (auto heap : heaps)
    {
        delete heap.second;
    }
}