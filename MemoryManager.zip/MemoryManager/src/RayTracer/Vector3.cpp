//#include "Vector3.h"
//#include "GlobalDefines.h"
//#include "HeapManager.h"
//
//template<typename T>
//void* Vector3<T>::operator new(size_t size)
//{
//    VERBOSE_OUTPUT(std::cout << "{Vector3<" << typeid(T).name() << ">} New Called" << std::endl;);
//    return ManagedObject::operator new(size, HeapManager::Instance()->GetHeap("Vector"));
//}
//
//template<typename T>
//void Vector3<T>::operator delete(void* pMem)
//{
//    VERBOSE_OUTPUT(std::cout << "{Vector3<" << typeid(T).name() << ">} Delete Called" << std::endl;);
//    ::operator delete(pMem);
//}
//
//template<typename T>
//void* Vector3<T>::operator new[](size_t size)
//{
//    VERBOSE_OUTPUT(std::cout << "{Vector3<" << typeid(T).name() << ">} New[] Called" << std::endl;);
//    return ManagedObject::operator new[](size, HeapManager::Instance()->GetDefaultHeap());
//}
//
//template<typename T>
//void Vector3<T>::operator delete[](void* pMem)
//{
//    VERBOSE_OUTPUT(std::cout << "{Vector3<" << typeid(T).name() << ">} Delete[] Called" << std::endl;);
//    ::operator delete[](pMem);
//}