#pragma once
#include "../MemoryManagement/ManagedObject.h"
#include "../MemoryManagement/HeapManager.h"
#include "../GlobalDefines.h"
#include <vector>

class Sphere;
class Animation;

class RayTracer : public ManagedObject
{
public:
    static void* operator new(size_t size);
    static void operator delete(void* pMem);
    static void* operator new[](size_t size);
    static void operator delete[](void* pMem);

    RayTracer();
    ~RayTracer();
    Animation* LoadScene(std::string filepath);
    void AnimatedRender(std::string filepath, unsigned width = 640, unsigned height = 480);
private:
    float Mix(const float& a, const float& b, const float& mix);
    Vector3f Trace(const Vector3f& rayorig, const Vector3f& raydir, const std::vector<Sphere>& spheres, const int& depth);
    void Render(const std::vector<Sphere>& spheres, int iteration, unsigned width = 640, unsigned height = 480);

    std::string filepath = "";
};

