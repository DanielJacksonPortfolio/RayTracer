#pragma once
#include "../MemoryManagement/ManagedObject.h"
#include "../GlobalDefines.h"
#include "Vector3.h"

class Sphere : public ManagedObject
{
public:
	Vector3f center;							/// position of the sphere
	float radius, radius2;						/// sphere radius and radius^2
	Vector3f surfaceColor, emissionColor;		/// surface color and emission (light)
	float transparency, reflection;				/// surface transparency and reflectivity
	int frameNum;
	Sphere(const int frameNum, const Vector3f& center, const float& radius, const Vector3f& surfaceColor, const float& reflection = 0, const float& transparency = 0, const Vector3f& emissionColor = 0);
	~Sphere();

	bool Intersect(const Vector3f& rayorig, const Vector3f& raydir, float& t0, float& t1) const;

	static void* operator new(size_t size);
	static void operator delete(void* pMem);
	static void* operator new[](size_t size);
	static void operator delete[](void* pMem);
};

